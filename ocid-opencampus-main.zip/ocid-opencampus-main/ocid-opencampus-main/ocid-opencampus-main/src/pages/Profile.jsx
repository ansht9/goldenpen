import React, { useState, useEffect } from 'react';
import { useOCAuth } from '@opencampus/ocid-connect-js';
import TopNavBar from './TopNavBar';
import SideNavBar from './SideNavBar';
import { navigate } from '@reach/router';
import { LoginButton } from '@opencampus/ocid-connect-js';

const Profile = () => {
    const { OCId, ethAddress, ocAuth, authState } = useOCAuth();
    const [playlistDetails, setPlaylistDetails] = useState({});
    const [expandedDescriptions, setExpandedDescriptions] = useState({});
    const playlistIds = [
        'PL4cUxeGkcC9gZD-Tvwfod2gaISzfRiP9d',
        'PLGjplNEQ1it8-0CmoljS5yeV-GlKSUEt0',
        'PLGjplNEQ1it_oTvuLRNqXfz_v_0pq6unW'
    ];

    useEffect(() => {
        if (authState && authState.isAuthenticated) {
            playlistIds.forEach(id => {
                fetchPlaylistDetails(id);
            });
        }
    }, [authState]);

    const fetchPlaylistDetails = async (playlistId) => {
        const url = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,id&maxResults=50&playlistId=${playlistId}&key=AIzaSyCN47V_shF9sEuqHJx8uQ1N22Dbbm5UC9Y`;
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error('Network response was not ok');
            const data = await response.json();
            const totalVideos = data.items.length;
            const watchedVideos = parseInt(localStorage.getItem(playlistId) || '0');
            const progressPercentage = totalVideos > 0 ? (watchedVideos / totalVideos) * 100 : 0;
            const thumbnailUrl = data.items[0]?.snippet?.thumbnails?.default?.url;
            const title = data.items[0]?.snippet?.title || "No title";
            const description = data.items[0]?.snippet?.description || "No description";
            setPlaylistDetails(prevDetails => ({
                ...prevDetails,
                [playlistId]: {
                    progress: progressPercentage,
                    thumbnail: thumbnailUrl,
                    title: title,
                    totalVideos: totalVideos,
                    description: description
                }
            }));
        } catch (error) {
            console.error('Error fetching playlist details:', error);
            setPlaylistDetails(prevDetails => ({
                ...prevDetails,
                [playlistId]: { progress: 0, thumbnail: null, title: "Error loading title", totalVideos: 0, description: "Error loading description" }  // Handle fetch failure
            }));
        }
    };

    const handlePlaylistSelect = (playlistId) => {
        navigate(`/playlist/${playlistId}`);
    };

    const toggleDescription = (playlistId) => {
        setExpandedDescriptions(prevState => ({
            ...prevState,
            [playlistId]: !prevState[playlistId]
        }));
    };

    if (!authState || !authState.isAuthenticated) {
        return <LoginButton />;
    }

    return (
        <div className='homediv'>
            <TopNavBar OCId={OCId} ethAddress={ethAddress} ocAuth={ocAuth} authState={authState} />
            <div className='bottomdiv'>
                <SideNavBar />
                <div className='profilediv'>
                    <h1>Profile</h1>
                    <div className='playlistcard'>
    {playlistIds.map(id => (
        <div key={id} className='playlistcard-item'>
            <button onClick={() => handlePlaylistSelect(id)}>
                Load Playlist
            </button>
            <span>{playlistDetails[id]?.title || "Loading..."}</span>
            {playlistDetails[id]?.thumbnail && <img src={playlistDetails[id].thumbnail} alt="Thumbnail" />}
            <div className='progress-bar'>
                <div style={{ width: `${playlistDetails[id]?.progress || 0}%` }}></div>
            </div>
            <span className='progress-percentage'>{Math.round(playlistDetails[id]?.progress || 0)}%</span>
            <div className='total-videos'>
                <span>Total Videos: {playlistDetails[id]?.totalVideos || 0}</span>
            </div>
            <div className='description-toggle'>
                <button onClick={() => toggleDescription(id)}>
                    {expandedDescriptions[id] ? 'Hide Description' : 'Show Description'}
                </button>
                {expandedDescriptions[id] && (
                    <div className='description'>
                        <span>{playlistDetails[id]?.description || "No description"}</span>
                    </div>
                )}
            </div>
        </div>
    ))}
</div>
                    
                </div>
            </div>
        </div>
    );
};

export default Profile;
