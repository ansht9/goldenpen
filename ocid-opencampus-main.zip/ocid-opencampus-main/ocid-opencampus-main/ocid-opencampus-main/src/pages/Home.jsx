import React, { useState, useEffect } from 'react';
import { navigate } from '@reach/router';
import { LoginButton, useOCAuth } from '@opencampus/ocid-connect-js';
import TopNavBar from './TopNavBar';
import SideNavBar from './SideNavBar';
import './index2.css';

const Home = () => {
  const { OCId, ethAddress, ocAuth, authState } = useOCAuth();
  const [playlistDetails, setPlaylistDetails] = useState({});
  const [expandedDescriptions, setExpandedDescriptions] = useState({});
  const playlistIds = [
      'PL4cUxeGkcC9gZD-Tvwfod2gaISzfRiP9d',
      'PLGjplNEQ1it8-0CmoljS5yeV-GlKSUEt0',
      'PLGjplNEQ1it_oTvuLRNqXfz_v_0pq6unW'
  ];

  useEffect(() => {
      if (authState && authState.isAuthenticated) {
          playlistIds.forEach(id => {
              fetchPlaylistDetails(id);
          });
      }
  }, [authState]);

  const fetchPlaylistDetails = async (playlistId) => {
      const itemsUrl = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,id&maxResults=50&playlistId=${playlistId}&key=AIzaSyCN47V_shF9sEuqHJx8uQ1N22Dbbm5UC9Y`;

      try {
          const itemsResponse = await fetch(itemsUrl);
          if (!itemsResponse.ok) throw new Error('Network response was not ok');
          const itemsData = await itemsResponse.json();
          const totalVideos = itemsData.items.length;
          const watchedVideos = parseInt(localStorage.getItem(playlistId) || '0');
          const progressPercentage = totalVideos > 0 ? (watchedVideos / totalVideos) * 100 : 0;
          const thumbnailUrl = itemsData.items[0]?.snippet?.thumbnails?.default?.url;
          const title = itemsData.items[0]?.snippet?.title || "No title";
          const description = itemsData.items[0]?.snippet?.description || "No description";

          let totalViews = 0;
          for (const item of itemsData.items) {
              const videoId = item.snippet.resourceId.videoId;
              const videoUrl = `https://www.googleapis.com/youtube/v3/videos?part=statistics&id=${videoId}&key=AIzaSyCN47V_shF9sEuqHJx8uQ1N22Dbbm5UC9Y`;
              const videoResponse = await fetch(videoUrl);
              if (!videoResponse.ok) throw new Error('Network response was not ok');
              const videoData = await videoResponse.json();
              totalViews += parseInt(videoData.items[0]?.statistics?.viewCount || '0');
          }

          setPlaylistDetails(prevDetails => ({
              ...prevDetails,
              [playlistId]: {
                  progress: progressPercentage,
                  thumbnail: thumbnailUrl,
                  title: title,
                  totalVideos: totalVideos,
                  description: description,
                  totalViews: totalViews
              }
          }));
      } catch (error) {
          console.error('Error fetching playlist details:', error);
          setPlaylistDetails(prevDetails => ({
              ...prevDetails,
              [playlistId]: { progress: 0, thumbnail: null, title: "Error loading title", totalVideos: 0, description: "Error loading description", totalViews: 0 }  // Handle fetch failure
          }));
      }
  };

  const handlePlaylistSelect = (playlistId) => {
      navigate(`/playlist/${playlistId}`);
  };

  const toggleDescription = (playlistId) => {
      setExpandedDescriptions(prevState => ({
          ...prevState,
          [playlistId]: !prevState[playlistId]
      }));
  };

  if (!authState || !authState.isAuthenticated) {
      return <LoginButton />;
  }

  return (
      <div className='homediv'>
          <TopNavBar OCId={OCId} ethAddress={ethAddress} ocAuth={ocAuth} authState={authState} />
          <div className='bottomdiv'>
              <SideNavBar />
              <div className='profilediv'>
                  <h1>Home</h1>
                                    <div className='playlistcard'>
                    {playlistIds.map(id => (
                        <div key={id} className='playlistcard-item'>
                            <button onClick={() => handlePlaylistSelect(id)}>
                                Load Playlist
                            </button>
                            <span>{playlistDetails[id]?.title || "Loading..."}</span>
                            {playlistDetails[id]?.thumbnail && <img src={playlistDetails[id].thumbnail} alt="Thumbnail" />}
                            <div className='progress-bar'>
                                <div style={{ width: `${playlistDetails[id]?.progress || 0}%` }}></div>
                            </div>
                            <span className='progress-percentage'>{Math.round(playlistDetails[id]?.progress || 0)}%</span>
                            <div className='total-videos'>
                                <span>Total Videos: {playlistDetails[id]?.totalVideos || 0}</span>
                            </div>
                            <div className='total-views'>
                                <span>Total Views: {playlistDetails[id]?.totalViews || 0}</span>
                            </div>
                            <div className='description-toggle'>
                                <button onClick={() => toggleDescription(id)}>
                                    {expandedDescriptions[id] ? 'Hide Description' : 'Show Description'}
                                </button>
                                {expandedDescriptions[id] && (
                                    <div className='description'>
                                        <span>{playlistDetails[id]?.description || "No description"}</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                    </div>

              </div>
          </div>
      </div>
  );
};

export default Home;
