// import React, { useState, useEffect } from 'react';

// const Counter = () => {
//   // Load the counter value from local storage or start at 0 if not found
//   const [count, setCount] = useState(() => {
//     const savedCount = localStorage.getItem('counterValue');
//     return savedCount !== null ? parseInt(savedCount, 10) : 0;
//   });

//   // Use useEffect to update local storage whenever count changes
//   useEffect(() => {
//     localStorage.setItem('counterValue', count);
//   }, [count]);

//   // Function to increment the counter
//   const increment = () => {
//     setCount((prevCount) => prevCount + 1);
//   };

//   return (
//     <div>
//       <button onClick={increment}>+</button>
//       <p>Count: {count}</p>
//     </div>
//   );
// };

// export default Counter;
