import React from "react";
import { Router, navigate } from "@reach/router";
import Home from "../pages/Home";
import Profile from "../pages/Profile";
import Settings from "../pages/Settings";
import { LoginCallBack } from "@opencampus/ocid-connect-js";
import VideoPlayer from "../pages/VideoPlayer";  // Ensure correct path

const AppRoutes = () => {
  const onLoginSuccess = () => {
    navigate('/');
  };

  const onLoginError = () => {
    console.log("Error");
  };

  const OCLoginCallback = () => (
    <LoginCallBack
      errorCallback={onLoginError}
      successCallback={onLoginSuccess}
    />
  );

  return (
    <Router>
      <Home path="/" />
      <Profile path="/profile" />
      <Settings path="/settings" />
      <VideoPlayer path="/playlist/:playlistId" />
      <OCLoginCallback path="redirect" />
    </Router>
  );
};

export default AppRoutes;