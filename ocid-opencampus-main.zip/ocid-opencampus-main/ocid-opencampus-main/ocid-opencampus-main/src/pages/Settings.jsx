import React from 'react';
import { useOCAuth } from '@opencampus/ocid-connect-js';
import TopNavBar from './TopNavBar';
import SideNavBar from './SideNavBar';

const Settings = () => {
    const { OCId, ethAddress, ocAuth, authState } = useOCAuth();

    return (
        <div className='homediv'>
            <SideNavBar />
            <TopNavBar OCId={OCId} ethAddress={ethAddress} ocAuth={ocAuth} authState={authState} />
            <h1>Settings</h1>
        </div>
    );
};

export default Settings;
