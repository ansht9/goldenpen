import React from 'react';
import { Link } from "@reach/router";
import './index.css';

const SideNavBar = () => {
    return (
        <div className="sidebar">
            <ul>
                <li><Link to="/" className="nav-link">Home</Link></li>
                <li><Link to="/profile" className="nav-link">Profile</Link></li>
                <li><Link to="/settings" className="nav-link">Settings</Link></li>
            </ul>
        </div>
    );
};

export default SideNavBar;
