import React from 'react';
import './index.css';
// import Wallet from './Wallet';

const TopNavBar = ({ OCId, ethAddress, ocAuth, authState }) => (
  <div className="topNavBar">
    <h4>User Info</h4>
    <pre>{OCId}</pre>
    {/* Uncomment and adjust the following lines as needed when you decide to use them:
    <pre>{ethAddress}</pre>
    <pre>{ocAuth.getStateParameter()}</pre>
    <pre>{JSON.stringify(authState)}</pre> */}
    {/* <Wallet></Wallet> */}
  </div>
);

export default TopNavBar;
