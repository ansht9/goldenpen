import React, { useState, useEffect } from 'react';
import { useParams } from '@reach/router';

const VideoPlayer = () => {
    const { playlistId } = useParams();
    const [videos, setVideos] = useState([]);
    const [currentVideoIndex, setCurrentVideoIndex] = useState(parseInt(localStorage.getItem(playlistId) || 0));
    const [userAnswer, setUserAnswer] = useState('');
    const [progress, setProgress] = useState(0);
    const API_KEY = 'AIzaSyCN47V_shF9sEuqHJx8uQ1N22Dbbm5UC9Y';

    useEffect(() => {
        fetchPlaylistItems();
    }, [playlistId]);

    useEffect(() => {
        setProgress((currentVideoIndex / (videos.length || 1)) * 100);
    }, [currentVideoIndex, videos.length]);

    const fetchPlaylistItems = async () => {
        const url = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&playlistId=${playlistId}&key=${API_KEY}`;
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error('Network response was not ok');
            const data = await response.json();
            setVideos(data.items);
        } catch (error) {
            console.error('Error fetching playlist items:', error);
        }
    };

    const handleQuizSubmit = (event) => {
        event.preventDefault();
        const correctAnswer = currentVideoIndex + 1;
        if (parseInt(userAnswer) === correctAnswer) {
            alert('Correct answer! Moving to the next video.');
            const nextVideoIndex = currentVideoIndex + 1;
            if (nextVideoIndex < videos.length) {
                setCurrentVideoIndex(nextVideoIndex);
                localStorage.setItem(playlistId, nextVideoIndex.toString());
            }
            setUserAnswer('');
        } else {
            alert('Wrong answer, please try again!');
        }
    };

    return (
        <div>
            {videos.length > 0 && (
                <div>
                    <iframe
                        width="560"
                        height="315"
                        src={`https://www.youtube.com/embed/${videos[currentVideoIndex].snippet.resourceId.videoId}?autoplay=1`}
                        frameBorder="0"
                        allow="autoplay; encrypted-media"
                        allowFullScreen
                    ></iframe>
                    <div className="video-quiz">
                        <form onSubmit={handleQuizSubmit}>
                            <label>
                                What's the video number? (Hint: It's video {currentVideoIndex + 1})
                                <input
                                    type="number"
                                    value={userAnswer}
                                    onChange={e => setUserAnswer(e.target.value)}
                                    required
                                />
                            </label>
                            <button type="submit">Submit Answer</button>
                        </form>
                    </div>
                    <div>
                        <progress value={progress} max="100"></progress>
                        <div>Quiz Progress: {Math.round(progress)}%</div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default VideoPlayer;
